import { defineConfig } from 'vite';

// Vite configuration for the Guru Maharaj portfolio.
// Vercel auto-detects Vite projects, so this works for `vercel deploy` out of the box.
export default defineConfig({
  root: '.',
  publicDir: 'public',
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    sourcemap: false,
    target: 'es2020',
    cssCodeSplit: false,
    assetsInlineLimit: 4096,
  },
  server: {
    port: 5173,
    open: true,
  },
  preview: {
    port: 4173,
  },
});
