# Guru Maharaj — Video Editor Portfolio

A premium dark-mode glassmorphism portfolio for a video editor specializing in podcast clipping. Built with **Vite + TypeScript**, ready to deploy to **Vercel** or **GitHub Pages**.

🔗 **Live preview:** https://yvotel45bln6.space.minimax.io/

## Tech stack

- **Vite 5** — build tooling & dev server
- **TypeScript 5** — strict type checking
- **Vanilla TS** — no framework, no runtime dependencies
- **Space Grotesk + Outfit** — Google Fonts
- **CSS** — glassmorphism, gradients, custom properties, animations

## Project structure

```
.
├── index.html              # HTML entry point (Vite root)
├── package.json
├── vite.config.ts
├── tsconfig.json
├── .gitignore
└── src/
    ├── main.ts             # JS entry — imports styles & boots script
    ├── script.ts           # Interactive behaviors (typed, strict)
    └── styles.css          # All styles (extracted, ~920 lines)
```

## Local development

```bash
# Install dependencies
npm install

# Start dev server (default: http://localhost:5173)
npm run dev

# Type-check + production build
npm run build

# Preview the production build
npm run preview
```

## Deploy to Vercel

### Option 1 — Vercel Dashboard
1. Push this repo to GitHub.
2. Import the project in [vercel.com/new](https://vercel.com/new).
3. Vercel auto-detects Vite. Click **Deploy**.

### Option 2 — Vercel CLI
```bash
npm i -g vercel
vercel        # first time — follow prompts
vercel --prod # production deploy
```

No `vercel.json` is required — Vite's default build output (`dist/`) is what Vercel expects.

## Deploy to GitHub Pages

1. In `vite.config.ts`, set the base path:
   ```ts
   export default defineConfig({
     base: '/your-repo-name/',
     // ...
   });
   ```
2. Build: `npm run build`
3. Push `dist/` to the `gh-pages` branch (or use `gh-pages` package).

## Customizing

- **Copy / sections** → edit `index.html`
- **Styles (colors, spacing, layout)** → edit `src/styles.css`
- **Behaviors (cursor, scroll, reveals, parallax)** → edit `src/script.ts`
- **Brand color** → change `--grad-1` and the blue variables in `:root` inside `src/styles.css`

## License

This portfolio was generated for Guru Maharaj. All rights reserved by the client.
