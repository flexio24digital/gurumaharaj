/* ============================================================
   Guru Maharaj — Video Editor Portfolio
   Interactive behaviors: cursor, scroll, reveals, parallax
   ============================================================ */

// ---------- Types ----------
type CursorElements = {
  cursor: HTMLElement;
  follower: HTMLElement;
};

// ---------- Custom Cursor ----------
function initCursor(): void {
  const cursor = document.querySelector<HTMLElement>('.cursor');
  const follower = document.querySelector<HTMLElement>('.cursor-follower');
  if (!cursor || !follower) return;

  const elements: CursorElements = { cursor, follower };
  let mx = 0;
  let my = 0;
  let fx = 0;
  let fy = 0;

  document.addEventListener('mousemove', (e: MouseEvent) => {
    mx = e.clientX;
    my = e.clientY;
    elements.cursor.style.transform =
      `translate(${mx}px, ${my}px) translate(-50%, -50%)`;
  });

  const animateFollower = (): void => {
    fx += (mx - fx) * 0.12;
    fy += (my - fy) * 0.12;
    elements.follower.style.transform =
      `translate(${fx}px, ${fy}px) translate(-50%, -50%)`;
    requestAnimationFrame(animateFollower);
  };
  animateFollower();

  // Expand cursor on interactive elements
  const interactiveSelector =
    'a, button, summary, .service-card, .work-card, .why-item, .process-step';
  document.querySelectorAll<HTMLElement>(interactiveSelector).forEach((el) => {
    el.addEventListener('mouseenter', () => {
      elements.cursor.classList.add('expand');
      elements.follower.classList.add('expand');
    });
    el.addEventListener('mouseleave', () => {
      elements.cursor.classList.remove('expand');
      elements.follower.classList.remove('expand');
    });
  });
}

// ---------- Nav scroll state ----------
function initNavScroll(): void {
  const nav = document.getElementById('nav');
  if (!nav) return;

  const onScroll = (): void => {
    if (window.scrollY > 30) {
      nav.classList.add('scrolled');
    } else {
      nav.classList.remove('scrolled');
    }
  };

  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
}

// ---------- Fade-up reveals ----------
function initReveals(): void {
  const targets = document.querySelectorAll<HTMLElement>('.reveal');
  if (targets.length === 0) return;

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
  );

  targets.forEach((el) => observer.observe(el));
}

// ---------- Parallax on hero orbs ----------
function initParallax(): void {
  const orbs = document.querySelectorAll<HTMLElement>('.hero-bg-orb');
  if (orbs.length === 0) return;

  const onScroll = (): void => {
    const y = window.scrollY;
    orbs.forEach((orb, i) => {
      const speed = i === 0 ? 0.15 : 0.1;
      orb.style.transform = `translate3d(0, ${y * speed}px, 0)`;
    });
  };

  window.addEventListener('scroll', onScroll, { passive: true });
}

// ---------- Smooth scroll for anchor links ----------
function initSmoothScroll(): void {
  const anchors = document.querySelectorAll<HTMLAnchorElement>('a[href^="#"]');
  anchors.forEach((anchor) => {
    anchor.addEventListener('click', (e: MouseEvent) => {
      const targetId = anchor.getAttribute('href');
      if (!targetId || targetId === '#' || targetId.length < 2) return;

      const target = document.querySelector<HTMLElement>(targetId);
      if (!target) return;

      e.preventDefault();
      const offset = 80;
      const y = target.getBoundingClientRect().top + window.scrollY - offset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    });
  });
}

// ---------- Boot ----------
export function init(): void {
  initCursor();
  initNavScroll();
  initReveals();
  initParallax();
  initSmoothScroll();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
