/* ============================================================
   Guru Maharaj — Video Editor Portfolio
   Application entry point
   ============================================================ */

import './styles.css';
import { init } from './script';

init();
